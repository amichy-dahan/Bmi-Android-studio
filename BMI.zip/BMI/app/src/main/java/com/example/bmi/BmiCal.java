package com.example.bmi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.slider.Slider;

import java.text.DecimalFormat;

public class BmiCal extends AppCompatActivity {
    private static final DecimalFormat df = new DecimalFormat("0.00");
    public static final int ONE_HUNDRED = 100;
    public static final int TEN = 10;
    public static final double ZERO_POINT_NINE = 0.9;


    Button button ;
    TextView FirstName;
    TextView LastName;
    TextView BmiCheck; // the end print
    Slider slider;
    TextView sliderText;
    EditText age; // the age of user
    EditText Weight;
    RadioGroup radioGroup;
    RadioButton radioButton1;
    RadioButton radioButton2;
    RadioButton radioButton3;
    TextView BmiC;
    TextView WeightC;
    TextView idealWeight;
    TextView realWeight;
    Button button1;


    float Temp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_cal);

        button = (Button) findViewById(R.id.buttonCheck);
        FirstName = (TextView) findViewById(R.id.textFirstName);
        LastName = (TextView) findViewById(R.id.TextLastName);
        BmiCheck = (TextView) findViewById(R.id.TextBmiCal);
        BmiC = (TextView) findViewById(R.id.BmiC);
        WeightC = (TextView) findViewById(R.id.WeightStatus);
        idealWeight = (TextView) findViewById(R.id.idealWeight);
        realWeight = (TextView) findViewById(R.id.realWeight);
        age = (EditText)findViewById(R.id.TextAge);
        Weight = (EditText)findViewById(R.id.TextWeight);
        radioGroup = (RadioGroup)findViewById(R.id.radioG2);
        radioButton1 = (RadioButton) findViewById(R.id.radioBg1);
        radioButton2 = (RadioButton) findViewById(R.id.radioBg2);
        radioButton3 = (RadioButton) findViewById(R.id.radioBg3);
        button1= (Button)findViewById(R.id.buttonClear);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirstName.setText("");
                LastName.setText("");
                age.setText("");
                Weight.setText("");
                BmiCheck.setText("");
                BmiC.setText("");
                WeightC.setText("");
                idealWeight.setText("");
                realWeight.setText("");
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (FirstName.getText().length() == 0 || LastName.getText().length() ==0 ||  age.getText().length()==0 ||
                        Weight.getText().length() == 0) {
                    BmiCheck.setText("please enter all details");
                }else {

                    BmiCheck.setText("HELLO " + FirstName.getText() + " " + LastName.getText());
                    double H = slider.getValue() / 100;
                    double W = Integer.parseInt(String.valueOf(Weight.getText()));
                    double resultH = H * H;
                    double BmiCalculate = W / resultH;
                    BmiC.setText("Your BMI: " + df.format(BmiCalculate));
                    if (BmiCalculate <= 15) {
                        WeightC.setText("Anorexic");
                    }
                    if (BmiCalculate >= 15 && BmiCalculate <= 18.5) {
                        WeightC.setText("Underweight");
                    }
                    if (BmiCalculate >= 18.5 && BmiCalculate <= 24.9) {
                        WeightC.setText("Normal");
                    }
                    if (BmiCalculate >= 25.0 && BmiCalculate <= 29.9) {
                        WeightC.setText("Overweight");
                    }
                    if (BmiCalculate >= 30.0 && BmiCalculate <= 35) {
                        WeightC.setText("Obese");
                    }
                    if (BmiCalculate > 35) {
                        WeightC.setText("Extreme Obese");
                    }
                    int Age;
                    double ideal;
                    if (radioButton1.isChecked()) {
                        Age = Integer.parseInt(String.valueOf(age.getText()));
                        ideal = (slider.getValue() - ONE_HUNDRED + (Age / TEN)) * ZERO_POINT_NINE * 0.9;
                        idealWeight.setText("ideal Weight : " +df.format((ideal)));
                        realWeight.setText("real Weight :" + Weight.getText());

                    }
                    if (radioButton2.isChecked()) {

                        Age = Integer.parseInt(String.valueOf(age.getText()));
                        ideal = (slider.getValue() - ONE_HUNDRED + (Age / TEN)) * ZERO_POINT_NINE * 1;
                        idealWeight.setText("ideal Weight : " +df.format((ideal)));
                        realWeight.setText("real Weight :" + Weight.getText());


                    }
                    if (radioButton3.isChecked()) {

                        Age = Integer.parseInt(String.valueOf(age.getText()));
                        ideal = (slider.getValue() - ONE_HUNDRED + (Age / TEN)) * ZERO_POINT_NINE * 1.1;
                        idealWeight.setText("ideal Weight : " +df.format((ideal)));
                        realWeight.setText("real Weight :" + Weight.getText());
                    }

                }
            }
        });

        slider = (Slider) findViewById(R.id.seekBar);
        sliderText = (TextView) findViewById(R.id.SliderText);
        slider.addOnSliderTouchListener(new Slider.OnSliderTouchListener() {

            @Override
            public void onStartTrackingTouch(@NonNull Slider slider) {
            }

            @Override
            public void onStopTrackingTouch(@NonNull Slider slider) {
                String c = String.valueOf(slider.getValue());
                sliderText.setText("your Height is: " + c);
            }


        });


    }


}





//
//    setOnClickListener(new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//            float value = slider.getValue();
//            Temp = slider.getValue();
//            String val = String.valueOf(value);
//            sliderText.setText("your Height is: " + val);
//        }
//    });