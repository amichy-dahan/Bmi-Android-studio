package com.example.bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//Amichy Dahan ID 314845025, amichyd1@gmail.com
//Eden tzanani  ID 203216791 , eden135790@gmail.com
//Second year, Computer Science Department- Ashqelon College


public class MainActivity extends AppCompatActivity {
     private Button start;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        start = (Button) findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openBmi();
            }
        });
    }

    public void openBmi() {
   Intent i = new Intent(this, BmiCal.class);
        startActivity(i);
    }


}